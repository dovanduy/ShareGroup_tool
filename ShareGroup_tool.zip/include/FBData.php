<?php

class FBData
{
    public $user_id;
    public $fb_dtsg;
    public $cookie;
    public $token;
    public $expiration_time;
    public $read;
    public $write;
    public $extended;
    public $seen_scopes;
}