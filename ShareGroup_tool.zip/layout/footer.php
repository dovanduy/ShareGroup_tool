<!--Footer-->
<footer class="page-footer font-medium blue fixed-bottom">
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3" style="color: white">
        © 2018 Copyright: Quang Thien - Design and Developed by PN Team.
    </div>
    <!-- Copyright -->
</footer>
<!--/.Footer-->
<script type="text/javascript" src="<?php echo PATH; ?>/public/lib/mdb/js/jquery-3.3.1.min.js"></script>
<!--<script type="text/javascript" src="--><?php //echo PATH; ?><!--/public/lib/mdb/js/popper.min.js"></script>-->
<script type="text/javascript" src="<?php echo PATH; ?>/public/lib/mdb/js/bootstrap.min.js"></script>
<!--<script type="text/javascript" src="--><?php //echo PATH; ?><!--/public/lib/mdb/js/mdb.min.js"></script>-->
<script type="text/javascript" src="<?php echo PATH; ?>/public/lib/sweetalert.min.js"></script>
<script type="text/javascript" src="<?php echo PATH; ?>/public/js/main.js"></script>
<script type="text/javascript" src="<?php echo PATH; ?>/public/js/javascript.js"></script>

</body>
</html>
